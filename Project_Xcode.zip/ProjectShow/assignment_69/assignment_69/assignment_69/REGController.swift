//
//  REGController.swift
//  assignment_69
//
//  Created by kuet on 16/11/23.
//

import UIKit
import FirebaseDatabase

class REGController: UIViewController {

    @IBOutlet weak var emailtext: UITextField!
    @IBOutlet weak var nametext: UITextField!
    @IBOutlet weak var passwordtext: UITextField!
    
    @IBOutlet weak var BL: UIButton!
    var ref: DatabaseReference!

    override func viewDidLoad() {
        super.viewDidLoad()
        ref = Database.database().reference()
    }

    
    func pushNewValue(email: String, password: String, name: String) {
        // Save data to Firebase Realtime Database
        
        var ss = password

        // Create a Hasher instance
        var hasher = Hasher()

        // Combine the hash value of the string
        hasher.combine(ss)

        // Get the final hash value
        let hashValue = hasher.finalize()

        // Print the hash value
        //print("Hash value: \(hashValue)")
        var phash = String(hashValue)
        
        let userData = ["email": email, "password": password, "name":name]
        //let userData = ["email": email, "password": password, "name":name]
        ref.child("users").child("info").child(email).setValue(userData)
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+2, execute: {
            self.performSegue(withIdentifier: "backtologin" , sender: nil)
        })
    }
    
    
    
    
    @IBAction func SU22(_ sender: Any) {
 
        
        if let email = emailtext.text, let password = passwordtext.text, let name = nametext.text {
            
        

    
            let Ekey = email.replacingOccurrences(of: ".", with: "")


        

            
            pushNewValue(email: Ekey, password: password , name: name)
        } else {
            //self.textview.text = "Invalid email or password"
        }
    }
    
    
    
    @IBAction func BL(_ sender: Any) {
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+1, execute: {
            self.performSegue(withIdentifier: "backtologin" , sender: nil)
        })
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
