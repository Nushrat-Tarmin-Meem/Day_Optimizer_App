import UIKit
import FirebaseDatabase

class ViewController: UIViewController{
    
    

    
    

    
    


    @IBOutlet var Button1: UIButton!
    @IBOutlet var textview: UILabel!
    @IBOutlet var viewEmail: UILabel!
    @IBOutlet var imageview1: UIImageView!
    @IBOutlet weak var passwordtext: UITextField!
    @IBOutlet weak var emailtext: UITextField!
 

    @IBOutlet weak var SU: UIButton!

    var ref: DatabaseReference!
    
    var dataToSend: String = "demo"
    
//    private let table: UITableView = {
//        let table = UITableView()
//        table.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
//        return table
//    }()
   

    override func viewDidLoad() {
        super.viewDidLoad()
        ref = Database.database().reference()
        
        
//        title = "Task List"
//
//        view.addSubview(table)
//        table.dataSource = self
        
    }
    
    
    
       override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "gotohome" {
            // Ensure that the destination view controller is named SwarajController
            if let destinationVC = segue.destination as? WeatherViewController {
                destinationVC.receivedData = dataToSend
            }
        }
    }
    
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return 0
//    }
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell  = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
//       // cell.textLabel?.text = items[indexPath.row]
//        return cell
//    }

   
//////////////////////////////////////////////////////////////
  
    
    @IBAction func SU(_ sender: Any) {
        
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now(), execute: {
            self.performSegue(withIdentifier: "SU1" , sender: nil)
        })
        
        
    }
    
    
    
    
    
    
    
    
    @IBAction func loginButton(_ sender: Any) {
        showSavedValue()
    }
    
    
    
    
    func showSavedValue() {
        
        
        
        
      
    
        
        if let email = emailtext.text, let password = passwordtext.text {
            
            let Ekey = email.replacingOccurrences(of: ".", with: "")


            var EMAIL: String!
            var PASSWORD: String!
            
            EMAIL=Ekey;
            PASSWORD=password;
            
            dataToSend=EMAIL
           
            
            
            var ss = password

            // Create a Hasher instance
            var hasher = Hasher()

            // Combine the hash value of the string
            hasher.combine(ss)

            // Get the final hash value
            let hashValue = hasher.finalize()

            // Print the hash value
            //print("Hash value: \(hashValue)")
            var phash = String(hashValue)
           
            
            
            
            
            
            
            
            ref.child("users").child("info").observeSingleEvent(of: .value) { (snapshot) in
                if let data = snapshot.value as? [String: Any] {
                    
                    
                    
                    
                    for (_, value) in data {
                        if let user = value as? [String: String] {
                            
                            
                            if let email = user["email"], let password = user["password"] {
                                if email == EMAIL && password == password {
                                    // Both email and password match
                                    //self.textview.text = "Logged in"
                                    
                                    //DispatchQueue.main.asyncAfter(deadline: DispatchTime.now(), execute: {
                                    //    self.performSegue(withIdentifier: "gotohome" , sender: nil)
                                    //})
                                    
                                    self.performSegue(withIdentifier: "gotohome", sender: self)
                                    
                                    
                                   // let data = PASSWORD.data(using: .utf8)! // mark 1
                                   // print(CryptoKit.SHA256.hash(data: data))
                                    
                                    
                                    
                                    // Add your code here for the case when both conditions are true
                                } else {
                                    //self.textview.text = "Login Failed"
                                    
                                    DispatchQueue.main.async { [self] in
                                       //    self.textview.text = "Saved Password: \(PASSWORD)"
                                        //   self.viewEmail.text = "Saved Username: \(EMAIL)"
                                       }
                                    
                                    //self.textview.text = "Saved Password: \( PASSWORD )"
                                    //self.viewEmail.text = "Saved Username: \( EMAIL )"
                                    // Either email or password doesn't match
                                    // Add your code here for the case when at least one condition is false
                                }
                            } else {
                                self.textview.text = "Invalid data in the user dictionary"
                                // Handle the case where email or password is missing or not of the correct type
                            }


                            
                            
                            
                        }
                    }
        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        // Fetch and display saved data from Firebase Realtime Database
       
                
                
                
                
            }
        }
         
    }
//////////////////////////////////////////////////////////////////////
   
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    @IBAction func Button1_click(_ sender: Any) {
       
        
        
    }
}



