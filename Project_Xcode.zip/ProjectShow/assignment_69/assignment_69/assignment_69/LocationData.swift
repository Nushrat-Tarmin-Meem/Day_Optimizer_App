//
//  LocationData.swift
//  assignment_69
//
//  Created by kuet on 23/11/23.
//

import Foundation
struct LocationData:Codable
{
    let name:String
    let country:String
    
}
