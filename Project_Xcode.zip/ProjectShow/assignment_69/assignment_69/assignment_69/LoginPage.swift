//
//  LoginPage.swift
//  assignment_69
//
//  Created by kuet on 7/11/23.
//

import SwiftUI

struct LoginPage: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct LoginPage_Previews: PreviewProvider {
    static var previews: some View {
        LoginPage()
    }
}
