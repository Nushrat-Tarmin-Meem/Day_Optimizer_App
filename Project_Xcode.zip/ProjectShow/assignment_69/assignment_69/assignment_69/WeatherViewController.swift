//
//  WeatherViewController.swift
//  assignment_69
//
//  Created by kuet on 23/11/23.
//

import UIKit

class WeatherViewController: UIViewController {

          
     
    var receivedData: String?
   var receivedData_M: String = "demo"
    
    
    
    @IBOutlet var entt: UITextField!
    @IBOutlet weak var ent: UIButton!
    ///
       
    @IBOutlet weak var inp: UITextField!
    @IBOutlet weak var Cr: UILabel!
   
    @IBOutlet weak var R: UILabel!
    @IBOutlet weak var T: UILabel!
    
    @IBOutlet weak var H: UILabel!

    @IBOutlet weak var W: UILabel!

        
    @IBOutlet weak var U: UILabel!


    @IBOutlet weak var C: UILabel!
    
    
   
    
    
    @IBOutlet weak var ref: UIButton!
    
        
        
    
    
    @IBOutlet weak var addNote: UIButton!
    
    
    
    
    
    
    
    
    
    
    
    
      
        override func viewDidLoad() {
            super.viewDidLoad()
         
            fetchData()
           // fetchData22()
        }
        
        
        
        
func displayReceivedData() {
        if let data = receivedData {
             receivedData_M=data
            //data1.text = data
        } else {
            receivedData_M="demo"
            //data1.text = "No data received"
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "data33" {
            // Ensure that the destination view controller is named SwarajController
            if let destinationVC = segue.destination as? Data_Show_ViewController {
                destinationVC.receivedData = receivedData_M
            }
        }
    }
    
    
    
    @IBAction func Back(_ sender: Any) {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now(), execute: {
            self.performSegue(withIdentifier: "blogin" , sender: nil)
        })
    }
    
    
    
    
    
    func fetchData22(){
        //var a : String?
        
        var a="aa"
        
        
        a = entt.text!
        
        a="Dhaka"
        
     
        
        
        //let url = URL(string: "https://api.weatherapi.com/v1/current.json?key=43ce580050ed441db7a60848231411&q=Khulna&aqi=no" )
        
        let url = URL(string: "https://api.weatherapi.com/v1/current.json?key=43ce580050ed441db7a60848231411&q=\(a)&aqi=no" )
       
        
        let dataTask = URLSession.shared.dataTask(with: url! , completionHandler: {
            (data, response, error) in
            guard let data = data, error == nil else
            {
                print("Error Occured")
                return
            }
            
            var  fullweatherData:WeatherData?
            do{
                fullweatherData = try JSONDecoder().decode(WeatherData.self, from: data)
            }
            catch{
                print("Error occcured when json data intered\(error)")
            }
            
            DispatchQueue.main.async {
                self.U.text = "Updated : \(fullweatherData!.current.last_updated)"
                self.R.text = "Region : \(fullweatherData!.location.name)"
                self.C.text = "Country : \(fullweatherData!.location.country)"
                self.T.text = "Temparature (Celsius) : \(fullweatherData!.current.temp_c) "
                self.H.text = "Humidity :  \(fullweatherData!.current.humidity)"
                self.W.text = "Wind (Km/Hr) :  \(fullweatherData!.current.wind_kph)"
            }
            
        })
        dataTask.resume()
       
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
        func fetchData(){
        
        displayReceivedData()
           
            
            let url = URL(string: "https://api.weatherapi.com/v1/current.json?key=43ce580050ed441db7a60848231411&q=Khulna&aqi=no" )
            
            //let url = URL(string: "https://api.weatherapi.com/v1/current.json?key=43ce580050ed441db7a60848231411&q=\(bb)&aqi=no" )

            let dataTask = URLSession.shared.dataTask(with: url! , completionHandler: {
                (data, response, error) in
                guard let data = data, error == nil else
                {
                    print("Error Occured")
                    return
                }
                
                var  fullweatherData:WeatherData?
                do{
                    fullweatherData = try JSONDecoder().decode(WeatherData.self, from: data)
                }
                catch{
                    print("Error occcured when json data intered\(error)")
                }
                
                DispatchQueue.main.async {
                    self.U.text = "Updated : \(fullweatherData!.current.last_updated)"
                    self.R.text = "Region : \(fullweatherData!.location.name)"
                    self.C.text = "Country : \(fullweatherData!.location.country)"
                    self.T.text = "Temparature (Celsius) : \(fullweatherData!.current.temp_c) "
                    self.H.text = "Humidity :  \(fullweatherData!.current.humidity)"
                    self.W.text = "Wind (Km/Hr) :  \(fullweatherData!.current.wind_kph)"
                }
                
            })
            dataTask.resume()
           
        }
    
    
    
    @IBAction func ADDDDDDD(_ sender: Any) {
        
        //DispatchQueue.main.asyncAfter(deadline: DispatchTime.now(), execute: {
         //   self.performSegue(withIdentifier: "data33" , sender: nil)
            
            
        //})
        
        performSegue(withIdentifier: "data33", sender: self)
        
        
        
    }
    
    
    
       
    
    
    @IBAction func Search22(_ sender: Any) {
        fetchData22()
    }
    
    

    @IBAction func ref(_ sender: Any) {
        fetchData()
    }
    
    
    
    
        
       
}
        


