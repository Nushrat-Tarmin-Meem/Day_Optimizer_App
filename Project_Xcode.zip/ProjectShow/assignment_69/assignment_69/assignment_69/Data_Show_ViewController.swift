import UIKit
import FirebaseDatabase

class Data_Show_ViewController: UIViewController {


 var receivedData: String?
   var receivedData_M: String = "demo"



    @IBOutlet weak var tableView: UITableView!
    
    var ref: DatabaseReference!
    var data: [[String: Any]] = []  // Array of dictionaries

    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
        ref = Database.database().reference()
        loadData()
    }
    
    
    
    
    
    
            
func displayReceivedData() {
        if let data = receivedData {
             receivedData_M=data
            //data1.text = data
        } else {
            receivedData_M="demo"
            //data1.text = "No data received"
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "add1" {
            // Ensure that the destination view controller is named SwarajController
            if let destinationVC = segue.destination as? HOMEViewController {
                destinationVC.receivedData = receivedData_M
            }
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    private func setupTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
    }
    
    
    @IBAction func Logout(_ sender: Any) {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now(), execute: {
            self.performSegue(withIdentifier: "backlogin", sender: nil)
         })
        
    }
    
    @IBAction func Addddd(_ sender: Any) {
       // DispatchQueue.main.asyncAfter(deadline: DispatchTime.now(), execute: {
        //    self.performSegue(withIdentifier: "add1", sender: nil)
       // })
        
        performSegue(withIdentifier: "add1", sender: self)
    }

    private func loadData() {
    
        displayReceivedData()
        
        ref.child("users").child("NOTE").child(receivedData_M).observe(.value) { (snapshot) in
            self.data.removeAll()

            for child in snapshot.children {
                if let childSnapshot = child as? DataSnapshot,
                   let value = childSnapshot.value as? [String: Any] {
                    // Include the key in the dictionary
                    var mutableValue = value
                    mutableValue["key"] = childSnapshot.key
                    self.data.append(mutableValue)
                }
            }

            self.tableView.reloadData()
        }
    }

    // Handle cell selection for deletion
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedData = data[indexPath.row]
        if let dataKey = selectedData["key"] as? String {
            deleteData(withKey: dataKey)
        }
    }

    // Function to delete data
    private func deleteData(withKey key: String) {
        ref.child("users").child("NOTE").child(receivedData_M).child(key).removeValue { error, _ in
            if let error = error {
                print("Error deleting data: \(error.localizedDescription)")
            } else {
                print("Data deleted successfully")
            }
        }
    }
}

extension Data_Show_ViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)

        let rowData = data[indexPath.row]

        if let note = rowData["note"] as? String {
            let formattedText = "Note: \(note)"
            cell.textLabel?.text = formattedText
        }

        return cell
    }
}

