//
//  TODOViewController.swift
//  assignment_69
//
//  Created by kuet on 26/11/23.
//

import UIKit

class TODOViewController:UIViewController, UITableViewDataSource, UITableViewDelegate {

    private let table: UITableView = {
        let table = UITableView()
        table.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        return table
    }()

    var items = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = " swaraj69's To Do list"
        
        view.addSubview(table)
        table.dataSource = self
        table.delegate = self // Set the delegate
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(didTapAdd))
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        table.frame = view.bounds
    }

    @objc private func didTapAdd() {
        let alert = UIAlertController(title: "New Item", message: "Enter new to-do list item!", preferredStyle: .alert)

        alert.addTextField { field in
            field.placeholder = "Enter Item..."
        }

        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        alert.addAction(UIAlertAction(title: "Done", style: .default) { [weak self] (_) in
            if let field = alert.textFields?.first, let text = field.text, !text.isEmpty {
                self?.items.append(text)
                self?.table.reloadData()
            }
        })

        present(alert, animated: true)
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell  = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = items[indexPath.row]
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let alert = UIAlertController(title: "Options", message: "Choose an action", preferredStyle: .actionSheet)

        alert.addAction(UIAlertAction(title: "Update", style: .default) { [weak self] (_) in
            self?.showUpdateAlert(at: indexPath)
        })

        alert.addAction(UIAlertAction(title: "Delete", style: .destructive) { [weak self] (_) in
            self?.items.remove(at: indexPath.row)
            tableView.reloadData()
        })

        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))

        present(alert, animated: true)
    }

    private func showUpdateAlert(at indexPath: IndexPath) {
        let alert = UIAlertController(title: "Update Item", message: "Enter the updated to-do list item!", preferredStyle: .alert)

        alert.addTextField { textField in
            textField.placeholder = "Enter Updated Item..."
            textField.text = self.items[indexPath.row]
        }

        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))

        alert.addAction(UIAlertAction(title: "Done", style: .default) { [weak self] (_) in
            if let field = alert.textFields?.first, let text = field.text, !text.isEmpty {
                self?.items[indexPath.row] = text
                self?.table.reloadData()
            }
        })

        present(alert, animated: true)
    }
}








/*
 
 
 var ss = "mataha Mundu"

 // Create a Hasher instance
 var hasher = Hasher()

 // Combine the hash value of the string
 hasher.combine(ss)

 // Get the final hash value
 let hashValue = hasher.finalize()

 // Print the hash value
 print("Hash value: \(hashValue)")

 */


