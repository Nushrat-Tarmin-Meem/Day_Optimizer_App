

//
//  REGController.swift
//  assignment_69
//
//  Created by kuet on 16/11/23.
//

import UIKit
import FirebaseDatabase

class HOMEViewController: UIViewController{


 var receivedData: String?
 var receivedData_M: String = "demo"




    @IBOutlet var addback: UIButton!
    @IBOutlet weak var notetext: UITextField!
    @IBOutlet weak var datetext: UITextField!
    @IBOutlet weak var timetext: UITextField!
    var ref: DatabaseReference!

    override func viewDidLoad() {
        super.viewDidLoad()
        ref = Database.database().reference()
        displayReceivedData()
    }
    
    
    
    
    
    
               
func displayReceivedData() {
        if let data = receivedData {
             receivedData_M=data
            //data1.text = data
        } else {
            receivedData_M="demo"
            //data1.text = "No data received"
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "addback" {
            // Ensure that the destination view controller is named SwarajController
            if let destinationVC = segue.destination as? Data_Show_ViewController {
                destinationVC.receivedData = receivedData_M
            }
        }
    }
    
    
    
    
    
    
    

    
    func pushNewValue(note: String) {
        // Save data to Firebase Realtime Database
        let Data = ["note": note]
        ref.child("users").child("NOTE").child(receivedData_M).childByAutoId().setValue(Data)
    }
    
    
    
    
    @IBAction func SU22(_ sender: Any) {
 
        
        if let note = notetext.text{
            
        


        

            
            pushNewValue(note: note)
        } else {
            //self.textview.text = "Invalid email or password"
        }
    }
    
    
    @IBAction func addback(_ sender: Any) {
        
        //DispatchQueue.main.asyncAfter(deadline: DispatchTime.now(), execute: {
         //   self.performSegue(withIdentifier: "addback" , sender: nil)
       // })
        
        performSegue(withIdentifier: "addback", sender: self)
    }
    
    
    
    
    
    
    


}




